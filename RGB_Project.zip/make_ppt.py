from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.ns import qn
from copy import deepcopy
from lxml import etree

# ============ تنظیمات اصلی ============
FONT_NAME = "B Nazanin"
PRIMARY   = RGBColor(0x1F, 0x3A, 0x68)   # سرمه‌ای تیره
ACCENT    = RGBColor(0xE8, 0x7A, 0x22)   # نارنجی
LIGHT_BG  = RGBColor(0xF4, 0xF6, 0xFA)   # طوسی روشن
WHITE     = RGBColor(0xFF, 0xFF, 0xFF)
DARK      = RGBColor(0x22, 0x2B, 0x3D)
GREEN     = RGBColor(0x2E, 0x8B, 0x57)
RED       = RGBColor(0xC0, 0x39, 0x2B)

prs = Presentation()
prs.slide_width  = Inches(13.333)
prs.slide_height = Inches(7.5)

# ============ توابع کمکی ============
def set_rtl(paragraph):
    """راست‌چین کردن پاراگراف برای فارسی"""
    pPr = paragraph._pPr
    if pPr is None:
        pPr = paragraph._p.get_or_add_pPr()
    pPr.set('rtl', '1')

def add_text(tf, text, size=18, bold=False, color=DARK, align=PP_ALIGN.RIGHT, rtl=True):
    p = tf.add_paragraph() if tf.paragraphs[0].text else tf.paragraphs[0]
    p.alignment = align
    if rtl:
        set_rtl(p)
    run = p.add_run()
    run.text = text
    run.font.name = FONT_NAME
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    # فونت برای زبان عربی/فارسی
    rPr = run._r.get_or_add_rPr()
    rFont = etree.SubElement(rPr, qn('a:cs'))
    rFont.set('typeface', FONT_NAME)
    return p

def add_bg(slide, color):
    bg = slide.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = color
    bg.line.fill.background()
    bg.shadow.inherit = False
    slide.shapes._spTree.remove(bg._element)
    slide.shapes._spTree.insert(2, bg._element)
    return bg

def add_band(slide, color, top, height):
    band = slide.shapes.add_shape(1, 0, top, prs.slide_width, height)
    band.fill.solid()
    band.fill.fore_color.rgb = color
    band.line.fill.background()
    return band

def add_title_bar(slide, title_text):
    add_band(slide, PRIMARY, 0, Inches(1.1))
    add_band(slide, ACCENT, Inches(1.1), Inches(0.08))
    tb = slide.shapes.add_textbox(Inches(0.4), Inches(0.2), Inches(12.5), Inches(0.8))
    tf = tb.text_frame
    tf.margin_right = Inches(0.3)
    add_text(tf, title_text, size=30, bold=True, color=WHITE)

def add_footer(slide, page_num):
    add_band(slide, PRIMARY, Inches(7.15), Inches(0.35))
    tb = slide.shapes.add_textbox(Inches(0.3), Inches(7.18), Inches(12.7), Inches(0.3))
    tf = tb.text_frame
    add_text(tf, f"ارزیابی LLMs در RAG  |  بنچ‌مارک RGB  |  صفحه {page_num}",
             size=11, color=WHITE, align=PP_ALIGN.CENTER)

def add_box(slide, left, top, width, height, fill_color, line_color=None):
    box = slide.shapes.add_shape(5, left, top, width, height)  # Rounded Rectangle
    box.fill.solid()
    box.fill.fore_color.rgb = fill_color
    if line_color:
        box.line.color.rgb = line_color
        box.line.width = Pt(1.5)
    else:
        box.line.fill.background()
    return box

def add_bullets(slide, left, top, width, height, items, size=18, color=DARK):
    tb = slide.shapes.add_textbox(left, top, width, height)
    tf = tb.text_frame
    tf.word_wrap = True
    for i, item in enumerate(items):
        if i == 0:
            p = tf.paragraphs[0]
        else:
            p = tf.add_paragraph()
        p.alignment = PP_ALIGN.RIGHT
        set_rtl(p)
        run = p.add_run()
        run.text = "•  " + item
        run.font.name = FONT_NAME
        run.font.size = Pt(size)
        run.font.color.rgb = color
        rPr = run._r.get_or_add_rPr()
        cs = etree.SubElement(rPr, qn('a:cs'))
        cs.set('typeface', FONT_NAME)
        p.space_after = Pt(8)

# ============ اسلاید ۱: جلد ============
def slide_cover():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, PRIMARY)
    # نوار تزئینی
    add_band(slide, ACCENT, Inches(3.4), Inches(0.12))
    # عنوان اصلی
    tb = slide.shapes.add_textbox(Inches(0.5), Inches(1.5), Inches(12.3), Inches(1.5))
    tf = tb.text_frame
    add_text(tf, "ارزیابی مدل‌های زبانی بزرگ",
             size=44, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    tb2 = slide.shapes.add_textbox(Inches(0.5), Inches(2.4), Inches(12.3), Inches(1))
    tf2 = tb2.text_frame
    add_text(tf2, "در سامانه تولید تقویت‌شده با بازیابی (RAG)",
             size=32, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)
    # زیرعنوان
    tb3 = slide.shapes.add_textbox(Inches(0.5), Inches(3.7), Inches(12.3), Inches(0.8))
    tf3 = tb3.text_frame
    add_text(tf3, "معرفی بنچ‌مارک RGB برای سنجش چهار توانایی بنیادین",
             size=22, color=WHITE, align=PP_ALIGN.CENTER)
    # نویسندگان
    tb4 = slide.shapes.add_textbox(Inches(0.5), Inches(5), Inches(12.3), Inches(0.6))
    tf4 = tb4.text_frame
    add_text(tf4, "Jiawei Chen, Hongyu Lin, Xianpei Han, Le Sun",
             size=16, color=WHITE, align=PP_ALIGN.CENTER, rtl=False)
    tb5 = slide.shapes.add_textbox(Inches(0.5), Inches(5.5), Inches(12.3), Inches(0.6))
    tf5 = tb5.text_frame
    add_text(tf5, "آکادمی علوم چین  |  AAAI 2024",
             size=16, color=WHITE, align=PP_ALIGN.CENTER)
    # نوار پایین
    add_band(slide, ACCENT, Inches(6.9), Inches(0.6))
    tb6 = slide.shapes.add_textbox(Inches(0.3), Inches(7), Inches(12.7), Inches(0.4))
    tf6 = tb6.text_frame
    add_text(tf6, "تهیه و ارائه: امید هاشمی مرند  |  پروژه درس مباحث علوم کامپیوتر",
             size=15, bold=True, color=WHITE, align=PP_ALIGN.CENTER)

# ============ اسلاید ۲: چکیده ============
def slide_abstract():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "چکیده مقاله")
    add_box(slide, Inches(0.6), Inches(1.5), Inches(12.1), Inches(5.4), WHITE, PRIMARY)
    tb = slide.shapes.add_textbox(Inches(1), Inches(1.8), Inches(11.3), Inches(4.8))
    tf = tb.text_frame
    tf.word_wrap = True
    add_text(tf, "تولید تقویت‌شده با بازیابی (RAG) چیست؟",
             size=22, bold=True, color=ACCENT)
    add_text(tf, "روشی نوید‌بخش برای کاهش پدیده «توهم» در مدل‌های زبانی بزرگ که با افزودن دانش خارجی به مدل، پاسخ‌های دقیق‌تر و قابل‌اعتمادتری تولید می‌کند.",
             size=17, color=DARK)
    add_text(tf, " ", size=10)
    add_text(tf, "مسئله اصلی:", size=22, bold=True, color=ACCENT)
    add_text(tf, "تحقیقات قبلی، ارزیابی دقیقی از تاثیر RAG بر مدل‌های مختلف ندارند و نقاط ضعف این روش به‌خوبی شناسایی نشده است.",
             size=17, color=DARK)
    add_text(tf, " ", size=10)
    add_text(tf, "راهکار پیشنهادی:", size=22, bold=True, color=ACCENT)
    add_text(tf, "ساخت بنچ‌مارک RGB برای ارزیابی چهار توانایی بنیادین RAG: مقاومت در برابر نویز، رد پاسخ منفی، یکپارچه‌سازی اطلاعات و مقاومت در برابر اطلاعات نادرست.",
             size=17, color=DARK)
    add_footer(slide, 2)

# ============ اسلاید ۳: مقدمه و انگیزه ============
def slide_intro():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "چرا به RAG نیاز داریم؟")

    titles = ["توهم در پاسخ‌ها", "دانش منسوخ", "نبود تخصص حوزه‌ای"]
    descs = [
        "مدل‌ها گاهی پاسخ‌های نادرست\nو ساختگی تولید می‌کنند.",
        "دانش مدل‌ها در زمان آموزش\nثابت شده و به‌روز نیست.",
        "در حوزه‌های خاص مثل\nپزشکی دانش کافی ندارند."
    ]
    colors = [RED, ACCENT, PRIMARY]

    for i in range(3):
        left = Inches(0.5 + i * 4.2)
        card_w = Inches(3.9)
        card_top = Inches(1.6)

        # کارت اصلی
        add_box(slide, left, card_top, card_w, Inches(2.4), WHITE, colors[i])

        # هدر رنگی (فقط عرض کارت)
        hdr = slide.shapes.add_shape(5, left, card_top, card_w, Inches(0.55))
        hdr.fill.solid(); hdr.fill.fore_color.rgb = colors[i]; hdr.line.fill.background()

        # عنوان
        tb = slide.shapes.add_textbox(left + Inches(0.1), card_top + Inches(0.05),
                                       card_w - Inches(0.2), Inches(0.5))
        add_text(tb.text_frame, titles[i], size=18, bold=True, color=WHITE, align=PP_ALIGN.CENTER)

        # توضیح
        tb2 = slide.shapes.add_textbox(left + Inches(0.15), card_top + Inches(0.7),
                                        card_w - Inches(0.3), Inches(1.5))
        tb2.text_frame.word_wrap = True
        add_text(tb2.text_frame, descs[i], size=14, color=DARK, align=PP_ALIGN.CENTER)

    # باکس راه‌حل
    add_box(slide, Inches(0.5), Inches(4.3), Inches(12.3), Inches(2.6), PRIMARY)

    tb = slide.shapes.add_textbox(Inches(0.8), Inches(4.5), Inches(11.7), Inches(0.6))
    add_text(tb.text_frame, "✨  راه‌حل: تولید تقویت‌شده با بازیابی (RAG)",
             size=22, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)

    tb2 = slide.shapes.add_textbox(Inches(1), Inches(5.2), Inches(11.3), Inches(1.5))
    tb2.text_frame.word_wrap = True
    add_text(tb2.text_frame,
             "با وصل کردن مدل زبانی به منابع خارجی (مثل موتورهای جستجو)\nپاسخ‌ها دقیق‌تر و به‌روزتر می‌شوند.",
             size=17, color=WHITE, align=PP_ALIGN.CENTER)
    add_text(tb2.text_frame,
             "اما RAG هم چالش‌های جدی دارد که در این مقاله بررسی می‌شوند!",
             size=17, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)

    add_footer(slide, 3)

# ============ اسلاید ۴: چهار توانایی ============
def slide_four_abilities():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "چهار توانایی بنیادین مورد ارزیابی")
    abilities = [
        ("۱. مقاومت در برابر نویز", "Noise Robustness",
         "توانایی استخراج اطلاعات مفید از میان اسناد پر از نویز و اطلاعات نامرتبط."),
        ("۲. رد پاسخ منفی", "Negative Rejection",
         "زمانی که هیچ سند مرتبطی وجود ندارد، مدل باید صادقانه بگوید: «نمی‌دانم»."),
        ("۳. یکپارچه‌سازی اطلاعات", "Information Integration",
         "ترکیب پاسخ‌های پراکنده از چندین سند برای پاسخ به سوالات پیچیده."),
        ("۴. مقاومت در برابر اطلاعات نادرست", "Counterfactual Robustness",
         "تشخیص خطاهای واقعی موجود در اسناد بازیابی‌شده و اصلاح آن‌ها.")
    ]
    colors = [ACCENT, GREEN, PRIMARY, RED]
    positions = [(0.5, 1.5), (6.85, 1.5), (0.5, 4.3), (6.85, 4.3)]
    for i, (title_fa, title_en, desc) in enumerate(abilities):
        x, y = positions[i]
        add_box(slide, Inches(x), Inches(y), Inches(6.3), Inches(2.6), WHITE, colors[i])
        # نوار رنگی بالا
        bar = slide.shapes.add_shape(5, Inches(x), Inches(y), Inches(6.3), Inches(0.75))
        bar.fill.solid(); bar.fill.fore_color.rgb = colors[i]; bar.line.fill.background()
        # عنوان فارسی
        tb = slide.shapes.add_textbox(Inches(x+0.2), Inches(y+0.1), Inches(5.9), Inches(0.6))
        add_text(tb.text_frame, title_fa, size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
        # عنوان انگلیسی
        tb2 = slide.shapes.add_textbox(Inches(x+0.2), Inches(y+0.85), Inches(5.9), Inches(0.4))
        add_text(tb2.text_frame, title_en, size=14, bold=True, color=colors[i], align=PP_ALIGN.CENTER, rtl=False)
        # توضیح
        tb3 = slide.shapes.add_textbox(Inches(x+0.3), Inches(y+1.35), Inches(5.7), Inches(1.2))
        add_text(tb3.text_frame, desc, size=16, color=DARK, align=PP_ALIGN.CENTER)
    add_footer(slide, 4)

# ============ اسلاید ۵: ساخت بنچ‌مارک RGB ============
def slide_rgb_construction():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "نحوه ساخت بنچ‌مارک RGB")

    steps = [
        ("۱", "جمع‌آوری اخبار",   "گردآوری آخرین خبرها\nبرای جلوگیری از\nسوگیری دانش قبلی"),
        ("۲", "تولید QA",         "استخراج خودکار سوال\nو پاسخ از متن خبر\nتوسط ChatGPT"),
        ("۳", "بازیابی اسناد",    "استفاده از\nGoogle Search API\nبرای دریافت ۱۰ صفحه"),
        ("۴", "رتبه‌بندی مجدد",   "انتخاب ۳۰ قطعه برتر\nبا مدل بازیابی متراکم\n(Dense Retrieval)"),
    ]

    card_w = Inches(2.85)
    gap = 0.25

    for i, (num, title, desc) in enumerate(steps):
        x = Inches(0.4 + i * 3.2)

        # دایره شماره
        cx = x + Inches(1.0)
        circle = slide.shapes.add_shape(9, cx, Inches(1.6), Inches(0.7), Inches(0.7))
        circle.fill.solid(); circle.fill.fore_color.rgb = ACCENT; circle.line.fill.background()
        tb = slide.shapes.add_textbox(cx, Inches(1.65), Inches(0.7), Inches(0.6))
        add_text(tb.text_frame, num, size=24, bold=True, color=WHITE, align=PP_ALIGN.CENTER, rtl=False)

        # کارت
        add_box(slide, x, Inches(2.5), card_w, Inches(2.5), WHITE, PRIMARY)

        # عنوان
        tb2 = slide.shapes.add_textbox(x + Inches(0.1), Inches(2.6), card_w - Inches(0.2), Inches(0.5))
        add_text(tb2.text_frame, title, size=16, bold=True, color=PRIMARY, align=PP_ALIGN.CENTER)

        # توضیح
        tb3 = slide.shapes.add_textbox(x + Inches(0.15), Inches(3.15), card_w - Inches(0.3), Inches(1.7))
        tb3.text_frame.word_wrap = True
        add_text(tb3.text_frame, desc, size=13, color=DARK, align=PP_ALIGN.CENTER)

        # فلش بین کارت‌ها
        if i < 3:
            ar = slide.shapes.add_shape(13, x + card_w + Inches(0.05),
                                         Inches(3.5), Inches(0.22), Inches(0.35))
            ar.fill.solid(); ar.fill.fore_color.rgb = ACCENT; ar.line.fill.background()

    # باکس آمار
    add_box(slide, Inches(0.4), Inches(5.3), Inches(12.5), Inches(1.6), PRIMARY)
    tb = slide.shapes.add_textbox(Inches(0.6), Inches(5.4), Inches(12.1), Inches(0.5))
    add_text(tb.text_frame, "📊  آمار مجموعه داده نهایی",
             size=19, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)

    tb2 = slide.shapes.add_textbox(Inches(0.6), Inches(5.95), Inches(12.1), Inches(0.8))
    tb2.text_frame.word_wrap = True
    add_text(tb2.text_frame,
             "۶۰۰ سوال پایه  +  ۲۰۰ سوال یکپارچه‌سازی  +  ۲۰۰ سوال خطایابی",
             size=16, color=WHITE, align=PP_ALIGN.CENTER)
    add_text(tb2.text_frame,
             "نیمی انگلیسی  ·  نیمی چینی",
             size=15, color=ACCENT, align=PP_ALIGN.CENTER)

    add_footer(slide, 5)

# ============ اسلاید ۶: مدل‌ها و معیارها ============
def slide_models_metrics():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "مدل‌ها و معیارهای ارزیابی")
    # سمت راست: مدل‌ها
    add_box(slide, Inches(6.85), Inches(1.5), Inches(6), Inches(5.4), WHITE, PRIMARY)
    add_band_x = slide.shapes.add_shape(5, Inches(6.85), Inches(1.5), Inches(6), Inches(0.6))
    add_band_x.fill.solid(); add_band_x.fill.fore_color.rgb = PRIMARY; add_band_x.line.fill.background()
    tb = slide.shapes.add_textbox(Inches(6.85), Inches(1.6), Inches(6), Inches(0.5))
    add_text(tb.text_frame, "🤖 شش مدل مورد ارزیابی", size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    models = ["ChatGPT (OpenAI)", "ChatGLM-6B", "ChatGLM2-6B",
              "Vicuna-7B-v1.3", "Qwen-7B-Chat", "BELLE-7B-2M"]
    tb2 = slide.shapes.add_textbox(Inches(7.1), Inches(2.3), Inches(5.6), Inches(4.5))
    tf = tb2.text_frame
    for m in models:
        p = tf.add_paragraph() if tf.paragraphs[0].text else tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        run = p.add_run(); run.text = "✓  " + m
        run.font.name = FONT_NAME; run.font.size = Pt(20)
        run.font.color.rgb = DARK; run.font.bold = True
        p.space_after = Pt(14)
    # سمت چپ: معیارها
    add_box(slide, Inches(0.5), Inches(1.5), Inches(6), Inches(5.4), WHITE, ACCENT)
    band2 = slide.shapes.add_shape(5, Inches(0.5), Inches(1.5), Inches(6), Inches(0.6))
    band2.fill.solid(); band2.fill.fore_color.rgb = ACCENT; band2.line.fill.background()
    tb3 = slide.shapes.add_textbox(Inches(0.5), Inches(1.6), Inches(6), Inches(0.5))
    add_text(tb3.text_frame, "📏 چهار معیار ارزیابی", size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    metrics = [
        ("دقت (Accuracy)", "برای نویز و یکپارچه‌سازی"),
        ("نرخ رد (Rejection Rate)", "برای رد پاسخ منفی"),
        ("نرخ تشخیص خطا (ED)", "برای کشف خطاهای واقعی"),
        ("نرخ اصلاح خطا (CR)", "برای ارائه پاسخ صحیح بعد از کشف خطا"),
    ]
    y = 2.4
    for name, desc in metrics:
        tb4 = slide.shapes.add_textbox(Inches(0.7), Inches(y), Inches(5.6), Inches(0.5))
        add_text(tb4.text_frame, "◆  " + name, size=18, bold=True, color=ACCENT, align=PP_ALIGN.RIGHT)
        tb5 = slide.shapes.add_textbox(Inches(0.9), Inches(y+0.45), Inches(5.4), Inches(0.5))
        add_text(tb5.text_frame, desc, size=14, color=DARK, align=PP_ALIGN.RIGHT)
        y += 1.05
    add_footer(slide, 6)

# ============ اسلاید ۷: نتایج نویز ============
def slide_noise_results():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "نتایج: مقاومت در برابر نویز")
    # یافته اصلی
    add_box(slide, Inches(0.5), Inches(1.5), Inches(12.3), Inches(1.2), GREEN)
    tb = slide.shapes.add_textbox(Inches(0.8), Inches(1.65), Inches(11.7), Inches(0.9))
    add_text(tb.text_frame, "✅ یافته اصلی: RAG عملکرد مدل‌ها را بهبود می‌دهد، اما با افزایش نویز افت شدیدی دارد",
             size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    # جدول نمونه
    add_box(slide, Inches(0.5), Inches(2.9), Inches(7.5), Inches(4), WHITE, PRIMARY)
    tb2 = slide.shapes.add_textbox(Inches(0.7), Inches(3), Inches(7.1), Inches(0.5))
    add_text(tb2.text_frame, "📉 افت دقت با افزایش نویز (انگلیسی)",
             size=18, bold=True, color=PRIMARY, align=PP_ALIGN.CENTER)
    data = [
        ["مدل", "نویز ۰٪", "نویز ۸۰٪", "افت"],
        ["ChatGPT", "96.3", "76.0", "-20.3"],
        ["ChatGLM2-6B", "91.3", "57.3", "-34.0"],
        ["Vicuna-7B", "87.7", "60.3", "-27.4"],
        ["Qwen-7B-Chat", "94.3", "73.7", "-20.6"],
    ]
    rows, cols = len(data), len(data[0])
    table = slide.shapes.add_table(rows, cols, Inches(0.7), Inches(3.5), Inches(7.1), Inches(3.2)).table
    for r in range(rows):
        for c in range(cols):
            cell = table.cell(r, c)
            cell.text = data[r][c]
            for para in cell.text_frame.paragraphs:
                para.alignment = PP_ALIGN.CENTER
                for run in para.runs:
                    run.font.name = FONT_NAME
                    run.font.size = Pt(15)
                    run.font.bold = (r == 0)
                    run.font.color.rgb = WHITE if r == 0 else DARK
            if r == 0:
                cell.fill.solid(); cell.fill.fore_color.rgb = PRIMARY
            elif r % 2 == 0:
                cell.fill.solid(); cell.fill.fore_color.rgb = LIGHT_BG
    # سه نوع خطا
    add_box(slide, Inches(8.3), Inches(2.9), Inches(4.5), Inches(4), WHITE, ACCENT)
    tb3 = slide.shapes.add_textbox(Inches(8.4), Inches(3), Inches(4.3), Inches(0.5))
    add_text(tb3.text_frame, "⚠️ سه دلیل اصلی خطا", size=18, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)
    errors = [
        ("اطلاعات دورافتاده", "وقتی پاسخ از سوال در متن دور است"),
        ("شواهد نامطمئن", "گمانه‌زنی‌ها مدل را گمراه می‌کنند"),
        ("ابهام مفهومی", "مدل مفاهیم مشابه را اشتباه می‌گیرد"),
    ]
    y = 3.55
    for t, d in errors:
        tb4 = slide.shapes.add_textbox(Inches(8.5), Inches(y), Inches(4.1), Inches(0.4))
        add_text(tb4.text_frame, "▸ " + t, size=15, bold=True, color=ACCENT)
        tb5 = slide.shapes.add_textbox(Inches(8.5), Inches(y+0.4), Inches(4.1), Inches(0.6))
        add_text(tb5.text_frame, d, size=13, color=DARK)
        y += 1.1
    add_footer(slide, 7)

# ============ اسلاید ۸: رد پاسخ منفی ============
def slide_rejection_results():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "نتایج: رد پاسخ منفی")

    # باکس هشدار بالا
    add_box(slide, Inches(0.5), Inches(1.5), Inches(12.3), Inches(1), RED)
    tb = slide.shapes.add_textbox(Inches(0.8), Inches(1.6), Inches(11.7), Inches(0.8))
    add_text(tb.text_frame, "❌  مدل‌ها در گفتن «نمی‌دانم» ضعیف عمل می‌کنند!",
             size=22, bold=True, color=WHITE, align=PP_ALIGN.CENTER)

    # ستون چپ: آمار
    col_top = Inches(2.7)
    col_h = Inches(4.1)
    add_box(slide, Inches(0.5), col_top, Inches(6), col_h, WHITE, PRIMARY)

    tb2 = slide.shapes.add_textbox(Inches(0.7), Inches(2.8), Inches(5.6), Inches(0.5))
    add_text(tb2.text_frame, "📊  بیشترین نرخ رد (Rejection)",
             size=17, bold=True, color=PRIMARY, align=PP_ALIGN.CENTER)

    tb3 = slide.shapes.add_textbox(Inches(0.8), Inches(3.4), Inches(5.4), Inches(3.2))
    tf = tb3.text_frame
    tf.word_wrap = True
    add_text(tf, "انگلیسی:  تنها ۴۵٪", size=20, bold=True, color=DARK)
    add_text(tf, "(ChatGPT - بهترین عملکرد)", size=14, color=DARK)
    add_text(tf, " ", size=8)
    add_text(tf, "چینی:  تنها ۴۳.۳٪", size=20, bold=True, color=DARK)
    add_text(tf, "(ChatGPT - بهترین عملکرد)", size=14, color=DARK)
    add_text(tf, " ", size=8)
    add_text(tf, "📌 در بیش از نیمی از موارد، مدل\nپاسخ نادرست تولید می‌کند.",
             size=15, color=RED)

    # ستون راست: نمونه خطا
    add_box(slide, Inches(6.8), col_top, Inches(6), col_h, WHITE, ACCENT)

    tb4 = slide.shapes.add_textbox(Inches(7), Inches(2.8), Inches(5.6), Inches(0.5))
    add_text(tb4.text_frame, "🔍  نمونه‌ای از خطا",
             size=17, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)

    tb5 = slide.shapes.add_textbox(Inches(7.1), Inches(3.4), Inches(5.4), Inches(3.2))
    tf2 = tb5.text_frame
    tf2.word_wrap = True
    add_text(tf2, "سوال:", size=14, bold=True, color=PRIMARY)
    add_text(tf2, "کارگردان فیلم Irredeemable کیست؟", size=14, color=DARK)
    add_text(tf2, " ", size=6)
    add_text(tf2, "پاسخ صحیح:", size=14, bold=True, color=GREEN)
    add_text(tf2, "Jeymes Samuel", size=14, color=GREEN)
    add_text(tf2, " ", size=6)
    add_text(tf2, "پاسخ مدل: ❌", size=14, bold=True, color=RED)
    add_text(tf2, "Adam McKay", size=14, color=RED)
    add_text(tf2, " ", size=6)
    add_text(tf2, "→ مدل حتی وقتی اطلاعات\nقطعی نیست حدس می‌زند.", size=13, color=DARK)

    add_footer(slide, 8)

# ============ اسلاید ۹: یکپارچه‌سازی ============
def slide_integration_results():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "نتایج: یکپارچه‌سازی اطلاعات")
    add_box(slide, Inches(0.5), Inches(1.5), Inches(12.3), Inches(1.2), ACCENT)
    tb = slide.shapes.add_textbox(Inches(0.8), Inches(1.65), Inches(11.7), Inches(0.9))
    add_text(tb.text_frame, "🧩 پاسخ‌گویی به سوالات چندبخشی برای LLMها چالش بزرگی است",
             size=22, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    # آمار
    add_box(slide, Inches(0.5), Inches(2.9), Inches(5.8), Inches(4), WHITE, PRIMARY)
    tb2 = slide.shapes.add_textbox(Inches(0.7), Inches(3), Inches(5.4), Inches(0.5))
    add_text(tb2.text_frame, "📊 بیشترین دقت (بدون نویز)", size=18, bold=True, color=PRIMARY, align=PP_ALIGN.CENTER)
    tb3 = slide.shapes.add_textbox(Inches(0.7), Inches(3.7), Inches(5.4), Inches(3))
    tf = tb3.text_frame
    add_text(tf, "انگلیسی: حداکثر ۶۰٪", size=22, bold=True, color=DARK, align=PP_ALIGN.CENTER)
    add_text(tf, " ", size=10)
    add_text(tf, "چینی: حداکثر ۶۷٪", size=22, bold=True, color=DARK, align=PP_ALIGN.CENTER)
    add_text(tf, " ", size=14)
    add_text(tf, "با افزودن نویز ۴۰٪:", size=16, bold=True, color=RED, align=PP_ALIGN.CENTER)
    add_text(tf, "دقت به ۴۳٪ و ۵۵٪ سقوط می‌کند", size=18, bold=True, color=RED, align=PP_ALIGN.CENTER)
    # سه نوع خطا
    add_box(slide, Inches(6.6), Inches(2.9), Inches(6.2), Inches(4), WHITE, ACCENT)
    tb4 = slide.shapes.add_textbox(Inches(6.8), Inches(3), Inches(5.8), Inches(0.5))
    add_text(tb4.text_frame, "⚠️ سه خطای رایج", size=18, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)
    errors = [
        ("خطای ادغام (۲۸٪)", "ترکیب اشتباه پاسخ دو زیرسوال"),
        ("خطای نادیده‌گرفتن (۲۸٪)", "پاسخ فقط به یکی از زیرسوالات"),
        ("خطای ناهم‌ترازی (۶٪)", "اختصاص اسناد اشتباه به سوال"),
    ]
    y = 3.55
    for t, d in errors:
        tb5 = slide.shapes.add_textbox(Inches(6.9), Inches(y), Inches(5.7), Inches(0.4))
        add_text(tb5.text_frame, "▸ " + t, size=16, bold=True, color=ACCENT)
        tb6 = slide.shapes.add_textbox(Inches(6.9), Inches(y+0.4), Inches(5.7), Inches(0.6))
        add_text(tb6.text_frame, d, size=14, color=DARK)
        y += 1.1
    add_footer(slide, 9)

# ============ اسلاید ۱۰: مقاومت در برابر خطا ============
def slide_counterfactual_results():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "نتایج: مقاومت در برابر اطلاعات نادرست")
    add_box(slide, Inches(0.5), Inches(1.5), Inches(12.3), Inches(1.2), RED)
    tb = slide.shapes.add_textbox(Inches(0.8), Inches(1.65), Inches(11.7), Inches(0.9))
    add_text(tb.text_frame, "🚨 مدل‌ها به‌سختی می‌توانند خطاهای موجود در اسناد را تشخیص دهند",
             size=22, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    # مقایسه
    add_box(slide, Inches(0.5), Inches(2.9), Inches(12.3), Inches(2.2), WHITE, PRIMARY)
    tb2 = slide.shapes.add_textbox(Inches(0.7), Inches(3), Inches(11.9), Inches(0.5))
    add_text(tb2.text_frame, "📊 مقایسه ChatGPT (انگلیسی)", size=20, bold=True, color=PRIMARY, align=PP_ALIGN.CENTER)
    data = [
        ["معیار", "بدون سند", "با سند خطادار", "تشخیص خطا", "اصلاح خطا"],
        ["مقدار (٪)", "89", "9", "8", "57.1"],
    ]
    table = slide.shapes.add_table(2, 5, Inches(0.7), Inches(3.6), Inches(11.9), Inches(1.4)).table
    for r in range(2):
        for c in range(5):
            cell = table.cell(r, c)
            cell.text = data[r][c]
            for para in cell.text_frame.paragraphs:
                para.alignment = PP_ALIGN.CENTER
                for run in para.runs:
                    run.font.name = FONT_NAME
                    run.font.size = Pt(16)
                    run.font.bold = True
                    run.font.color.rgb = WHITE if r == 0 else DARK
            if r == 0:
                cell.fill.solid(); cell.fill.fore_color.rgb = PRIMARY
            else:
                cell.fill.solid(); cell.fill.fore_color.rgb = LIGHT_BG
    # نتیجه‌گیری
    add_box(slide, Inches(0.5), Inches(5.3), Inches(12.3), Inches(1.6), ACCENT)
    tb3 = slide.shapes.add_textbox(Inches(0.8), Inches(5.45), Inches(11.7), Inches(0.5))
    add_text(tb3.text_frame, "💡 نکته کلیدی", size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    tb4 = slide.shapes.add_textbox(Inches(0.8), Inches(5.95), Inches(11.7), Inches(1))
    add_text(tb4.text_frame,
             "حتی وقتی مدل خودش پاسخ صحیح را می‌داند، باز هم به اطلاعات نادرستِ اسناد بازیابی‌شده اعتماد می‌کند و دچار خطا می‌شود.",
             size=17, color=WHITE, align=PP_ALIGN.CENTER)
    add_footer(slide, 10)

# ============ اسلاید ۱۱: جمع‌بندی ============
def slide_conclusion():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, LIGHT_BG)
    add_title_bar(slide, "جمع‌بندی و نتیجه‌گیری")
    # خلاصه چالش‌ها
    add_box(slide, Inches(0.5), Inches(1.5), Inches(6), Inches(5.4), WHITE, RED)
    band = slide.shapes.add_shape(5, Inches(0.5), Inches(1.5), Inches(6), Inches(0.6))
    band.fill.solid(); band.fill.fore_color.rgb = RED; band.line.fill.background()
    tb = slide.shapes.add_textbox(Inches(0.5), Inches(1.6), Inches(6), Inches(0.5))
    add_text(tb.text_frame, "❌ چالش‌های شناسایی‌شده", size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    items = [
        "افت شدید دقت با افزایش نویز بالای ۸۰٪",
        "ضعف جدی در رد سوالات بدون پاسخ",
        "ناتوانی در ترکیب اطلاعات از چند سند",
        "اعتماد بیش از حد به اطلاعات نادرست بازیابی‌شده",
        "گیج‌شدن با مفاهیم مشابه و شواهد نامطمئن",
    ]
    add_bullets(slide, Inches(0.7), Inches(2.3), Inches(5.6), Inches(4.5), items, size=16, color=DARK)
    # پیشنهادات
    add_box(slide, Inches(6.85), Inches(1.5), Inches(6), Inches(5.4), WHITE, GREEN)
    band2 = slide.shapes.add_shape(5, Inches(6.85), Inches(1.5), Inches(6), Inches(0.6))
    band2.fill.solid(); band2.fill.fore_color.rgb = GREEN; band2.line.fill.background()
    tb2 = slide.shapes.add_textbox(Inches(6.85), Inches(1.6), Inches(6), Inches(0.5))
    add_text(tb2.text_frame, "✅ مسیرهای پیشنهادی", size=20, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    items2 = [
        "بهبود مدل‌سازی اسناد طولانی",
        "ارتقای درک دقیق مفاهیم",
        "آموزش مدل برای صداقت در نادانستن",
        "استفاده از روش زنجیره تفکر (CoT)",
        "طراحی محتاطانه و دقیق سامانه‌های RAG",
    ]
    add_bullets(slide, Inches(7.05), Inches(2.3), Inches(5.6), Inches(4.5), items2, size=16, color=DARK)
    add_footer(slide, 11)

# ============ اسلاید ۱۲: پایانی ============
def slide_thanks():
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    add_bg(slide, PRIMARY)
    add_band(slide, ACCENT, Inches(3.3), Inches(0.15))
    tb = slide.shapes.add_textbox(Inches(0.5), Inches(2), Inches(12.3), Inches(1.5))
    add_text(tb.text_frame, "با تشکر از توجه شما", size=54, bold=True, color=WHITE, align=PP_ALIGN.CENTER)
    tb2 = slide.shapes.add_textbox(Inches(0.5), Inches(3.6), Inches(12.3), Inches(1))
    add_text(tb2.text_frame, "🙏  پرسش و پاسخ", size=32, bold=True, color=ACCENT, align=PP_ALIGN.CENTER)
    tb3 = slide.shapes.add_textbox(Inches(0.5), Inches(5.5), Inches(12.3), Inches(0.6))
    add_text(tb3.text_frame, "📄 منبع: Chen et al., AAAI 2024", size=18, color=WHITE, align=PP_ALIGN.CENTER, rtl=False)
    tb4 = slide.shapes.add_textbox(Inches(0.5), Inches(6.1), Inches(12.3), Inches(0.6))
    add_text(tb4.text_frame, "🔗 github.com/chen700564/RGB", size=16, color=WHITE, align=PP_ALIGN.CENTER, rtl=False)

# ============ اجرا ============
slide_cover()
slide_abstract()
slide_intro()
slide_four_abilities()
slide_rgb_construction()
slide_models_metrics()
slide_noise_results()
slide_rejection_results()
slide_integration_results()
slide_counterfactual_results()
slide_conclusion()
slide_thanks()

output = "RGB_Presentation.pptx"
prs.save(output)
print(f"✅ فایل پاورپوینت با موفقیت ساخته شد: {output}")
print(f"📊 تعداد اسلایدها: {len(prs.slides)}")