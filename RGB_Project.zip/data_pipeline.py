import os
import json
import subprocess
import pandas as pd
from sentence_transformers import SentenceTransformer
from config import DATA_DIR, CONFIG, BASE_DIR

def run_data_pipeline():
    print("\n" + "="*50)
    print("🚀 شروع فرآیند پردازش داده‌ها (مراحل 1 تا 6)")
    print("="*50)

    # ==============================================================
    # مرحله 1 و 2: Pre-processing & Data Collection (جمع‌آوری داده)
    # ==============================================================
    print("\n[مرحله 1 و 2] در حال جمع‌آوری داده‌ها...")
    repo_path = DATA_DIR / "RGB_repo"
    
    # اگر دیتاست قبلاً دانلود نشده بود، از گیت‌هاب رسمی مقاله دانلودش می‌کنیم
    if not repo_path.exists():
        subprocess.run(["git", "clone", "https://github.com/chen700564/RGB.git", str(repo_path)], check=True)
    
    # مسیر فایل‌های دیتاست برای 4 توانایی مختلف (از پوشه دانلود شده)
    data_paths = {
        "noise_robustness": repo_path / "data/en.json",
        "negative_rejection": repo_path / "data/en.json",
        "information_integration": repo_path / "data/en_int.json",
        "counterfactual_robustness": repo_path / "data/en_fact.json"
    }

    # ==============================================================
    # مرحله 3: Data Understanding (درک داده‌ها)
    # ==============================================================
    print("\n[مرحله 3] درک و بارگذاری داده‌ها...")
    raw_data = {}
    for name, path in data_paths.items():
        if path.exists():
            # فایل‌های JSONL (هر خط یک JSON) را خط به خط می‌خوانیم
            with open(path, "r", encoding="utf-8") as f:
                raw_data[name] = [json.loads(line) for line in f if line.strip()]
            print(f"   ✓ بخش {name}: {len(raw_data[name])} نمونه پیدا شد.")

    # ==============================================================
    # مرحله 4: Data Cleaning (پاک‌سازی داده‌ها)
    # ==============================================================
    print("\n[مرحله 4] پاک‌سازی داده‌های ناقص...")
    cleaned_data = {}
    for name, items in raw_data.items():
        clean_list = []
        for item in items:
            # اگر سوال یا جوابی در دیتای فعلی خالی بود، آن را دور می‌اندازیم
            if not item.get("query") or not item.get("answer"):
                continue
            
            # فاصله‌های اضافی و اینترهای (Enter) اضافی را از سوال پاک می‌کنیم
            item["query"] = str(item["query"]).strip().replace("\n", " ")
            clean_list.append(item)
            
        cleaned_data[name] = clean_list
        print(f"   ✓ پس از پاک‌سازی {name}: {len(clean_list)} نمونه سالم ماند.")

    # ==============================================================
    # مرحله 5: Data Integration (یکپارچه‌سازی داده‌ها)
    # ==============================================================
    print("\n[مرحله 5] یکپارچه‌سازی تمام داده‌ها در یک جدول...")
    rows = []
    # تمام دیتاست‌های مختلف را در یک ساختار جدولی (DataFrame) جمع می‌کنیم
    for tb_name, items in cleaned_data.items():
        for item in items:
            rows.append({
                "testbed": tb_name,         # نوع آزمایش (مثلا مقاومت در برابر نویز)
                "id": item.get("id", 0),    # شناسه سوال
                "query": item["query"],     # متن سوال
                "answer": str(item["answer"]) # متن جواب اصلی
            })
    df_integrated = pd.DataFrame(rows)
    # خروجی را برای مراحل بعدی به صورت فایل CSV ذخیره می‌کنیم
    df_integrated.to_csv(DATA_DIR / "integrated_data.csv", index=False)
    print(f"   ✓ جدول یکپارچه با {df_integrated.shape[0]} ردیف ساخته شد.")

    # ==============================================================
    # مرحله 6: Data Transformation (تبدیل داده به بردار/Embedding)
    # ==============================================================
    print("\n[مرحله 6] Data Transformation (تبدیل متن به بردار ریاضی)...")
    # مدل تعبیه (Embedding) را می‌سازیم تا بعداً بتوانیم روی متن‌ها ماشین لرنینگ اعمال کنیم
    embedder = SentenceTransformer(CONFIG["embedding_model"])
    
    # 100 سوال اول را به اعداد برداری تبدیل می‌کنیم (تبدیل کلمات به ریاضیات برای کامپیوتر)
    queries_to_embed = df_integrated["query"].head(100).tolist()
    embeddings = embedder.encode(queries_to_embed)
    print(f"   ✓ متن {len(queries_to_embed)} سوال به بردارهای ریاضی تبدیل شد.")

    # برگرداندن داده‌های تمیز شده برای استفاده در مراحل بعدی
    return cleaned_data, df_integrated

if __name__ == "__main__":
    run_data_pipeline()