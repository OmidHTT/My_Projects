import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor, IsolationForest
from sklearn.cluster import KMeans
from sklearn.metrics import classification_report
from mlxtend.frequent_patterns import apriori, association_rules
from config import RESULTS_DIR, MODELS_DIR

def run_ml_pipeline(results_df):
    """
    این تابع روی نتایج به‌دست‌آمده از سیستم RAG، مدل‌های کلاسیک ماشین لرنینگ را اجرا می‌کند
    تا رفتار سیستم RAG را تحلیل کنیم (نوآوری پروژه شما).
    """
    print("\n" + "="*50)
    print("📊 شروع فرآیند ماشین لرنینگ کلاسیک و تحلیل روی نتایج RAG")
    print("="*50)

    # ==============================================================
    # مرحله 8: Feature Engineering (مهندسی ویژگی)
    # ==============================================================
    print("\n[مرحله 8] Feature Engineering...")
    # استخراج ویژگی‌های جدید: طول سوال چقدر است؟ آیا سوال عدد دارد؟
    results_df["query_length"] = results_df["query"].apply(lambda x: len(str(x).split()))
    results_df["answer_length"] = results_df["answer"].apply(lambda x: len(str(x).split()))
    results_df["has_number"] = results_df["query"].apply(lambda x: int(any(c.isdigit() for c in str(x))))

    # ==============================================================
    # مرحله 7 و 20: EDA & Visualization (تحلیل اکتشافی و تصویرسازی)
    # ==============================================================
    print("\n[مرحله 7 و 20] رسم نمودارها (Visualization)...")
    plt.figure(figsize=(10, 5))
    sns.histplot(results_df["query_length"], bins=20, kde=True, color="blue")
    plt.title("توزیع طول سوالات ارسالی به RAG")
    # ذخیره تصویر در پوشه results
    plt.savefig(RESULTS_DIR / "eda_query_length.png")
    plt.close()

    # ==============================================================
    # مرحله 9: Feature Selection (انتخاب ویژگی‌های مهم)
    # ==============================================================
    print("\n[مرحله 9] Feature Selection...")
    # ستون‌هایی که برای آموزش مدل ماشین لرنینگ نیاز داریم را جدا می‌کنیم
    features = ["query_length", "answer_length", "has_number", "noise_ratio"]
    X = results_df[features].fillna(0)
    y = results_df["correct"].astype(int) # هدف: آیا سیستم RAG توانست جواب درست بدهد یا خیر؟

    # ==============================================================
    # مرحله 10: Classification (طبقه‌بندی)
    # ==============================================================
    print("\n[مرحله 10] Classification (پیش‌بینی موفقیت مدل RAG)...")
    if len(y.unique()) > 1:
        # از جنگل تصادفی استفاده می‌کنیم تا ببینیم آیا می‌توان پیش‌بینی کرد مدل RAG چه زمانی اشتباه می‌کند؟
        clf = RandomForestClassifier(n_estimators=50, random_state=42)
        clf.fit(X, y)
        print("   ✓ گزارش طبقه‌بندی جنگل تصادفی:")
        print(classification_report(y, clf.predict(X), zero_division=0))
        # ذخیره مدل برای استفاده در آینده
        joblib.dump(clf, MODELS_DIR / "rag_classifier.pkl")

    # ==============================================================
    # مرحله 11: Regression (رگرسیون)
    # ==============================================================
    print("\n[مرحله 11] Regression (پیش‌بینی افت دقت بر اساس نویز)...")
    # ساخت مدلی که حدس می‌زند هرچه نویز بیشتر شود، سیستم RAG چقدر افت کیفیت دارد
    reg = RandomForestRegressor(n_estimators=50)
    reg.fit(X[["noise_ratio"]], y)
    print(f"   ✓ مدل رگرسیون آموزش داده شد.")

    # ==============================================================
    # مرحله 12: Clustering (خوشه‌بندی)
    # ==============================================================
    print("\n[مرحله 12] Clustering (خوشه‌بندی سوالات)...")
    # سوالات را به 2 دسته (خوشه) تقسیم می‌کند تا ببینیم سوالات سخت از آسان جدا می‌شوند یا خیر
    kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
    results_df["cluster"] = kmeans.fit_predict(X)
    print(f"   ✓ سوالات سیستم RAG به 2 خوشه تقسیم شدند.")

    # ==============================================================
    # مرحله 14: Anomaly Detection (تشخیص ناهنجاری)
    # ==============================================================
    print("\n[مرحله 14] Anomaly Detection (شناسایی باگ‌های عجیب)...")
    # پیدا کردن تست‌هایی که رفتار مدل RAG در آن‌ها بسیار غیرعادی بوده است
    iso = IsolationForest(contamination=0.1, random_state=42)
    results_df["anomaly"] = iso.fit_predict(X)
    print(f"   ✓ {len(results_df[results_df['anomaly'] == -1])} پاسخ غیرعادی/مشکوک در خروجی RAG شناسایی شد.")

    # ==============================================================
    # مرحله 13: Association Rules (قوانین انجمنی)
    # ==============================================================
    print("\n[مرحله 13] Association Rules...")
    # پیدا کردن قوانینی مثل: "اگر نویز بالا باشد AND سوال طولانی باشد => مدل جواب غلط می‌دهد"
    ar_df = X.copy()
    ar_df["long_query"] = ar_df["query_length"] > ar_df["query_length"].mean()
    ar_df["high_noise"] = ar_df["noise_ratio"] > 0.4
    ar_df["is_correct"] = y.astype(bool)
    ar_df = ar_df[["long_query", "high_noise", "has_number", "is_correct"]].astype(bool)
    
    try:
        freq = apriori(ar_df, min_support=0.1, use_colnames=True)
        rules = association_rules(freq, metric="confidence", min_threshold=0.6)
        print("   ✓ قوانین استخراج شد (مثلاً تاثیر ترکیب نویز و طول سوال بر خطا).")
    except:
        print("   ✓ حجم داده برای قوانین قدرتمند کافی نبود.")

    # ==============================================================
    # مرحله 18 و 19: Interpretation & Optimization (تفسیر و بهینه‌سازی)
    # ==============================================================
    print("\n[مرحله 18 و 19] Interpretation (کدام عامل بیشترین تاثیر را بر خرابی RAG دارد؟)...")
    if len(y.unique()) > 1:
        # رسم نمودار اینکه کدام ویژگی (مثل نویز یا طول سوال) باعث خطای RAG شده است
        importances = pd.Series(clf.feature_importances_, index=features)
        importances.plot(kind="barh", color="green", title="Feature Importance on RAG Errors")
        plt.savefig(RESULTS_DIR / "feature_importance.png")
        plt.close()
        print(f"   ✓ مهم‌ترین عامل تغییر دقت RAG: {importances.idxmax()}")

    # ذخیره نهایی
    results_df.to_csv(RESULTS_DIR / "final_ml_results.csv", index=False)