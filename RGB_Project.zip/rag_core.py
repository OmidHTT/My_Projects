import time
import random
import pandas as pd
from tqdm import tqdm
from groq import Groq
from config import GROQ_API_KEY, CONFIG, RESULTS_DIR

# ساخت کلاینت برای اتصال به مدل هوش مصنوعی Groq
client = Groq(api_key=GROQ_API_KEY)

# پرامپت سیستمی: به هوش مصنوعی می‌گوییم قانون بازی چیست (دقیقا طبق مقاله RGB)
SYSTEM_PROMPT = """You are an accurate AI. If documents have the answer, answer accurately. If not, output 'I can not answer the question because of the insufficient information in documents.' If documents contain factual errors, output 'There are factual errors in the provided documents.' and provide correct answer."""

def query_llm(query, docs):
    """
    این تابع هسته اصلی RAG است: ترکیب اسناد (Retrieval) با پرامپت و ارسال به LLM
    """
    # اسناد پیدا شده را پشت سر هم می‌چسبانیم
    doc_text = "\n".join([f"[Doc] {d}" for d in docs])
    
    # سوال کاربر و اسناد را در یک پرامپت واحد ترکیب می‌کنیم (Augmented Generation)
    prompt = f"Documents:\n{doc_text}\n\nQuestion:\n{query}"
    
    try:
        # ارسال درخواست به مدل زبانی
        res = client.chat.completions.create(
            model=CONFIG["llm_model"],
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT}, 
                {"role": "user", "content": prompt}
            ],
            temperature=0.0 # صفر می‌گذاریم تا جواب‌ها خلاقانه نباشد، بلکه دقیق و بر اساس متن باشد
        )
        # برگرداندن جواب تولید شده
        return res.choices[0].message.content.strip()
    except Exception as e:
        # اگر اینترنت قطع شد یا محدودیت API خوردیم، ۲ ثانیه صبر می‌کند
        time.sleep(2)
        return "API_ERROR"

def check_accuracy(response, answer):
    """
    بررسی اینکه آیا جواب مدل، شامل کلمه کلیدی پاسخ اصلی هست یا خیر (Exact Match)
    """
    return int(str(answer).lower() in str(response).lower())

def run_rag_experiments(cleaned_data):
    """
    مرحله 16 و 17: Model Training & Evaluation
    در این تابع، سیستم RAG را در شرایط مختلف (با نویز و بدون نویز) ارزیابی می‌کنیم.
    """
    print("\n" + "="*50)
    print("🧠 [مرحله 16 و 17] ارزیابی هسته RAG")
    print("="*50)
    
    results = []
    sample_size = CONFIG["sample_size"]
    
    # تست اول مقاله: Noise Robustness (مقاومت سیستم در برابر اسناد نامرتبط)
    print("\n🔬 ارزیابی مقاومت RAG در برابر اطلاعات نامرتبط (نویز)...")
    samples = cleaned_data.get("noise_robustness", [])[:sample_size]
    
    # تست سیستم با درصدهای مختلف از نویز (مثلا 0 درصد بی‌ربط، 40 درصد بی‌ربط و...)
    for ratio in CONFIG["noise_ratios"]:
        for item in tqdm(samples, desc=f"میزان نویز {ratio}"):
            
            # محاسبه اینکه چند سند بی‌ربط (neg) و چند سند مرتبط (pos) نیاز داریم
            num_neg = int(CONFIG["num_docs"] * ratio)
            num_pos = CONFIG["num_docs"] - num_neg
            
            # ترکیب اسناد مثبت و منفی و بر هم زدن ترتیب آن‌ها (تا مدل تقلب نکند)
            docs = (item.get("positive", [])[:num_pos] + item.get("negative", [])[:num_neg])
            random.shuffle(docs)
            
            # پاس دادن اسناد و سوال به مدل زبانی
            response = query_llm(item["query"], docs)
            
            # ذخیره نتایج این تست
            results.append({
                "testbed": "noise", 
                "noise_ratio": ratio,
                "query": item["query"], 
                "answer": item["answer"],
                "response": response, 
                "correct": check_accuracy(response, item["answer"]) # بررسی درستی جواب
            })
            time.sleep(1) # وقفه برای جلوگیری از بلاک شدن توسط سرورهای Groq

    # ذخیره تمام نتایج پاسخگویی مدل در یک فایل CSV
    df_results = pd.DataFrame(results)
    df_results.to_csv(RESULTS_DIR / "rag_experiment_results.csv", index=False)
    print("\n✅ ارزیابی سیستم RAG تمام شد.")
    
    return df_results