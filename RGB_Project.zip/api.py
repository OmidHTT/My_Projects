from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
from typing import List
import uvicorn
import datetime
from config import CONFIG, LOGS_DIR
from rag_core import query_llm

# ==============================================================
# مرحله 21: Deployment (استقرار مدل برای استفاده در وب یا اپلیکیشن)
# ==============================================================
app = FastAPI(title="RGB RAG Benchmark API", description="API برای چت با سیستم RAG")

# تعریف فرمت استاندارد درخواست کاربر (ورودی API)
class QueryRequest(BaseModel):
    query: str          # سوال کاربر
    documents: List[str] # اسنادی که سرچ انجین پیدا کرده است

# ==============================================================
# مرحله 22: Monitoring (مانیتورینگ و ثبت وقایع)
# ==============================================================
def log_request(query, response):
    """
    هر بار که کسی از سیستم سوالی می‌پرسد، در یک فایل لاگ ثبت می‌شود
    تا بتوانیم رفتار کاربران را مانیتور کنیم.
    """
    with open(LOGS_DIR / "api_monitoring.log", "a", encoding="utf-8") as f:
        log_entry = f"{datetime.datetime.now()} | Q: {query} | R: {response}\n"
        f.write(log_entry)

@app.get("/")
def home():
    return {"message": "API سیستم RAG فعال است. به مسیر /docs برای تست مراجعه کنید."}

@app.post("/ask")
def ask_rag(req: QueryRequest, bg_tasks: BackgroundTasks):
    """
    اندپوینت اصلی RAG: سوال و اسناد را می‌گیرد، از LLM جواب می‌سازد و برمی‌گرداند.
    """
    # پاس دادن به هسته مدل زبانی
    response = query_llm(req.query, req.documents)
    
    # ثبت کردن این سوال و جواب در پس‌زمینه (Background) بدون کند کردن کاربر (Monitoring)
    bg_tasks.add_task(log_request, req.query, response)
    
    return {
        "query": req.query,
        "response": response,
        "model_used": CONFIG["llm_model"]
    }

def start_api():
    print("\n[مرحله 21 و 22] Deployment & Monitoring...")
    print("🌐 سرور RAG در حال اجراست...")
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")